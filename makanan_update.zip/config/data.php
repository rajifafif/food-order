<?php

return [
    'food_types' => [
        [
            'name' => 'Makanan',
            'slug' => 'makanan'
        ],
        [
            'name' => 'Minuman Dingin',
            'slug' => 'minuman-dingin'
        ],
        [
            'name' => 'Minuman Panas',
            'slug' => 'minuman-panas'
        ],
        [
            'name' => 'Cemilan',
            'slug' => 'cemilan'
        ],
    ]
];
