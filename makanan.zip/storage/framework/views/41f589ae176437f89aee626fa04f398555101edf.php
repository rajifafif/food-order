<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($table->orders)): ?>
                <div class="col-xs-6 col-md-3">
                    <a href="<?php echo e(route('orders.edit', $table->orders->first->id)); ?>" class="small-box bg-warning">
                        <div class="inner">
                        <h3><?php echo e($table->name); ?><sup style="font-size: 20px">(<?php echo e($table->seat); ?>)</sup></h3>
                        </div>
                        <span class="small-box-footer">View Order <i class="fas fa-arrow-plus"></i></span>
                    </a>
                </div>
            <?php else: ?>
            <div class="col-xs-6 col-md-3">
                <a href="<?php echo e(route('order-table', $table->id)); ?>" class="small-box bg-success">
                    <div class="inner">
                    <h3><?php echo e($table->name); ?><sup style="font-size: 20px">(<?php echo e($table->seat); ?>)</sup></h3>
                    </div>
                    <span class="small-box-footer">Open Order <i class="fas fa-arrow-plus"></i></span>
                </a>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/pwa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/dashboard.blade.php ENDPATH**/ ?>