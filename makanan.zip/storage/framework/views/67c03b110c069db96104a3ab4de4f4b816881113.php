<?php $__env->startPush('css'); ?>
hello darkness my old friend
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/layouts/custom.blade.php ENDPATH**/ ?>