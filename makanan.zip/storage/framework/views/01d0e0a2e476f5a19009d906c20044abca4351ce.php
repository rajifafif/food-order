<?php $__env->startSection('title', 'Food'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Order #<?php echo e($order->order_nbr); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <table class="table table-bordered">
            <table class="table table-bordered" id="table-food-order">
                <tbody>
                    <tr>
                        <th>#</th>
                        <th>Menu</th>
                        <th>Jumlah</th>
                        <th>Total Price</th>
                    </tr>
                    <?php $__currentLoopData = $order->food_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="food-item">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($food_order->food->name ?? ''); ?></td>
                            <td><?php echo e($food_order->qty); ?></td>
                            <td><?php echo e($food_order->total_price); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th colspan="3" class="text-right">Total</th>
                        <th><?php echo e(\Helper::moneyFormat($order->total_price)); ?></th>
                    </tr>
                </tbody>
            </table>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/orders/view.blade.php ENDPATH**/ ?>