<?php $__env->startSection('title', 'Edit Order'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Order <span id="order_id" data-id="<?php echo e($order->id); ?>"><?php echo e($order->order_nbr); ?></span></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                
            </div>
            <div style="max-height: 500px; overflow-y: scroll">
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-success"><i class="far fa-flag"></i></span><!-- /TODO Display Food Image -->

                    <div class="info-box-content">
                        <span class="info-box-text"><?php echo e($food->name); ?></span>
                        <span class="info-box-number"><?php echo e(\Helper::moneyFormat($food->price)); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                    <?php if($food->status == 'ready'): ?>
                        <a class="info-box-icon btn btn-outline-success add-food" data-food_id="<?php echo e($food->id); ?>"><i class="fas fa-plus"></i></a>
                    <?php else: ?>
                        <a href="#" class="info-box-icon btn btn-outline-default disabled"><i class="fas fa-plus"></i></a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-8">
            <table class="table table-bordered" id="table-food-order">
                <tr>
                    <th>#</th>
                    <th>Menu</th>
                    <th>Total Price</th>
                    <th>Jumlah</th>
                </tr>
            </table>
            <?php if($order->status == 'open'): ?>
            <form action="<?php echo e(route('order-close', $order)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <button type="submit" class="btn btn-block btn-primary">Close Order</button>
                </div>
            </form>
            <?php else: ?>
                <div class="form-group">
                    <a href="#" type="submit" class="btn btn-block btn-primary disabled">Order Sudah Selesai</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <style>
        .order-qty-action i{
            font-size: 25px
        }
        .order-qty-action input{
            margin: 0 15px;
            width: 60px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script>
        $(document).ready(function(){
            var orderId = $('#order_id').data('id');
            var csrf_token = $('meta[name="csrf-token"]').attr('content');
            $.ajaxSetup({
                headers:
                { 'X-CSRF-TOKEN': csrf_token }
            });
            var orderData = <?php echo json_encode($order); ?>;

            var editOrder = {
                init: function(){
                    editOrder.addFoodButton();
                   if (orderData.food_orders) {
                        editOrder.orderDataToTable(orderData.food_orders);
                        editOrder.orderTotalTable(orderData.food_orders);
                   }
                },
                addFoodButton: function(){
                    $('.add-food').on('click', function(){
                        var foodId = $(this).data('food_id');

                        $.post('/order-add-food', {
                            'order_id' : orderId,
                            'food_id' : foodId,
                        }).then( function (response){
                            var data = response;
                            var food_orders = response.food_orders;
                            editOrder.orderDataToTable(food_orders);
                        });
                    })
                },
                orderQtyChange: function() {
                    $('.qty').on('change', function() {
                        var qty = $(this).val();
                        var foodId = $(this).data('food_id');

                        $.post('/order-add-food', {
                            'order_id' : orderId,
                            'food_id' : foodId,
                            'qty' : qty
                        }).then( function (response){
                            var data = response;
                            var food_orders = response.food_orders;
                            editOrder.orderDataToTable(food_orders);
                        });
                    })
                },
                orderDelete: function() {
                    $('.delete-food-order').on('click', function() {
                        var foodId = $(this).data('food_id');

                        $.post('/order-delete-food', {
                            'order_id' : orderId,
                            'food_id' : foodId,
                        }).then( function (response){
                            var data = response;
                            var food_orders = response.food_orders;
                            editOrder.orderDataToTable(food_orders);
                        });
                    })
                },
                orderDataToTable: function(data) {
                    let foodOrder;
                    $('.food-item').remove();
                    for (let index = 0; index < data.length; index++) {
                        foodOrder = data[index];
                        let tr = $('<tr class="food-item"></tr>');
                        let number = $('<td></td>').text(index+1);
                        let name = $('<td></td>').text(foodOrder.food.name);
                        let price = $('<td></td>').text(foodOrder.total_price);
                        let jumlah = $('<td class="order-qty-action d-flex justify-content-center"></td>');
                        let input = $('<input type="number" name="qty" class="qty" data-food_id="'+foodOrder.food_id+'" min="1" value="'+foodOrder.qty+'">');
                        let deleteBtn = $('<i class="fas fa-times text-danger delete-food-order" data-food_id="'+foodOrder.food_id+'"></i>');
                        jumlah.append(input).append(deleteBtn);

                        $(tr).append(number)
                            .append(name)
                            .append(price)
                            .append(jumlah)

                        $('#table-food-order').append(tr);
                    }


                    editOrder.orderQtyChange();
                    // editOrder.addFoodButton();
                    editOrder.orderDelete();
                },
                orderTotalTable: function(data) {

                }
            }

            editOrder.init();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/orders/edit.blade.php ENDPATH**/ ?>