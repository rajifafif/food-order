<!DOCTYPE html>
<html lang="en">

<head>
        <link rel="stylesheet" href="http://localhost:8080/vendor/adminlte/dist/css/adminlte.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

</head>
<body>
    <h1>Laporan Aktifivas <?php echo e(auth()->user()->name); ?></h1>
    <p>Total Order : <?php echo e($orders->count()); ?></p>
<table class="table table-bordered">
    <tr>
        <th style="width: 35;">#</th>
        <th>Order Number</th>
        <th>Table</th>
        <th>Status</th>
        <th>Total Food</th>
        <th>Total Price</th>
    </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($order->order_nbr); ?></td>
            <td><?php echo e($order->table->name ?? ''); ?></td>
            <td><?php echo e(ucfirst($order->status)); ?></td>
            <td><?php echo e($order->total_food); ?></td>
            <td><?php echo e(\Helper::moneyFormat($order->total_price)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<p class="text-right">generated at: <?php echo e(now()); ?></p>
</body>
<?php /**PATH E:\Work\html\makanan\resources\views/orders/print.blade.php ENDPATH**/ ?>