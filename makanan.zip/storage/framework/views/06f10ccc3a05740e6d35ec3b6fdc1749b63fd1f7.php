<?php $__env->startPush('css'); ?>
    <meta name="theme-color" content="#000">
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('vendor/adminlte/dist/img/AdminLTELogo.png')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src='<?php echo e(asset('js/app.js')); ?>'></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/layouts/pwa.blade.php ENDPATH**/ ?>