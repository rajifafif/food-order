<?php $__env->startSection('title', 'Order'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Order List</h1>
    <hr>
    <?php if(auth()->user()->hasRole('Pelayan')): ?>
    <a href="<?php echo e(route('orders.print')); ?>" class="btn btn-info">Cetak Laporan</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered">
        <tr>
            <th style="width: 35;">#</th>
            <th>Order Number</th>
            <th>Table</th>
            <th>Status</th>
            <th>Total Food</th>
            <th>Total Price</th>
            <th style="width: 130px">Action</th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($order->order_nbr); ?></td>
                <td><?php echo e($order->table->name ?? ''); ?></td>
                <td><?php echo e(ucfirst($order->status)); ?></td>
                <td><?php echo e($order->total_food); ?></td>
                <td><?php echo e(\Helper::moneyFormat($order->total_price)); ?></td>
                <td>
                    <?php if($order->status == 'open'): ?>
                        <a href="<?php echo e(route('orders.edit', $order)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-sm btn-success">View</a>
                    <?php endif; ?>
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/orders/index.blade.php ENDPATH**/ ?>