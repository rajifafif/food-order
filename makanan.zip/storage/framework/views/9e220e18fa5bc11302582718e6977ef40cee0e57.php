<?php $__env->startSection('title', 'Food'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Food List</h1>
    <hr>
    <a href="<?php echo e(route('foods.create')); ?>" class="btn btn-primary">Tambah Food</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered">
        <tr>
            <th style="width: 35;">#</th>
            <th>Name</th>
            <th>Status</th>
            <th>Price</th>
            <th style="width: 130px">Action</th>
        </tr>
        <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($food->name); ?></td>
                <td><?php echo e(\Helper::deSlug($food->type)); ?></td>
                <td><?php echo e($food->status == 'empty' ? 'Habis' : 'Ready'); ?></td>
                <td><?php echo e(\Helper::moneyFormat($food->price)); ?></td>
                <td>
                    <a href="<?php echo e(route('foods.edit', $food)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="#" onclick="event.preventDefault();
                    document.getElementById('food-<?php echo e($food->id); ?>-delete').submit();" class="btn btn-sm btn-danger">
                        Delete
                    </a>
                    <form id="food-<?php echo e($food->id); ?>-delete" action="<?php echo e(route('foods.destroy', $food)); ?>" method="POST" style="display: none;" onsubmit="return confirm('Do you really want to submit the form?');">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($foods->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\html\makanan\resources\views/foods/index.blade.php ENDPATH**/ ?>